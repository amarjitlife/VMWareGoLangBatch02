
____________________________________________________________

GO ENVIRONMENT SETUP GENERIC
____________________________________________________________

01. Download Go Compiler
	https://go.dev/dl/

	Download Go Compiler 
		As Per Your Operating System and Architecture

02. Install Go Compiler		
	For Windows/MacOSX
		Click On Go Compiler Executable To Install

	For Linux Machine
		Download
			Linux 2.6.32 or later, Intel 64-bit processor
			go1.19.4.linux-amd64.tar.gz (142MB)

		Extract It
			tar -xvzf go1.19.4.linux-amd64.tar.gz

			It Will Extract Go Compiler In

				go Directory

03. Add Go Compiler To PATH Variable 

	export PATH=$PATH:YOUR_PATH/go/bin

_________________________________________________________

TEST GO ENVIRONMENT!
_________________________________________________________
/*
Process 01
	To Build Go Program
		go build Hello.go

	To Run Go Compiled Program
		./Hello

Process 02
	To Run Go Program
		go run Hello.go
*/

package main

import "fmt"

func main() {
	fmt.Println("Hello World!")
}

_________________________________________________________
_________________________________________________________

