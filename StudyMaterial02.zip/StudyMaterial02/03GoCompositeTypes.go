
package main

import (
	"fmt"
)

//__________________________________________________________________

func playWithDefaultInitialValues() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 
	var c2 complex128

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

//__________________________________________________________________

// Composite Types, the molecules created by combining 
//		The basic types in various ways. 
// We'll talk about four such types
// 		arrays, structs, slices, maps

// Arrays and structs are aggregate types; 
// 		Their values are concatenations of other values in memory. 
//		Arrays are homogeneous?
//			Their elements all have the same type?
//		whereas structs are heterogeneous. 

//	Both arrays and structs are fixed size. 
//	In contrast, slices and maps are dynamic data structures that 
//		grow as values are added.

//__________________________________________________________________

func playWithArrays() {
	var a[3]int

	// range Generates Sequence Of Tuples
	//		[ (0, 0), (1, 0), (2, 0) ]
	//		Unpacking Tuple Values On index And value
	for index, value := range a { // index. value are local to loop
		fmt.Printf("\nAt Index: %d Value: %v", index, value)
	}
	fmt.Println()

	fmt.Println( a[0], a[1], a[2] )
	fmt.Println( a[ len(a) - 1] )

	// panic: runtime error: index out of range [3] with length 3
	// for i := 0 ; i < 5 ; i++ {
	// 		fmt.Printf("\nAt Index: %d Value: %v", i, a[i])		
	// }

	// range Generates Sequence Of Tuples
	//		[ (0, 0), (1, 0), (2, 0) ]
	//		Unpacking Tuple Values On _ And value
	//		_ Variable Name Means Ignore Value
	
	var aaa[3]int = [3]int{ 11, 22, 33 }
	for _, value := range aaa {
		fmt.Printf("\nValue: %v", value)
	}
	fmt.Println()

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(q) )
	for index, value := range q {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}	

	var qq = [5]int{ 10, 20, 30, 40, 50 }
	var rr = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(qq) )
	for index, value := range qq {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(rr) )
	for index, value := range rr {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}	

	s := [...]int{10, 20, 100, 111}
	// What Is Type Of s
	// 	1. Inferred From RHS
	//			RHS Type [4]int
	//	2. LHS Type Binded To [4]int
	fmt.Println("Array Length : ", len(s) )
	fmt.Printf("\nArray Type : %T \n", s )

	for index, value := range s {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	someAgain := [...]int{ 99 : -1 }
	fmt.Println("Array Length : ", len(someAgain) )
	fmt.Printf("\nArray Type : %T \n", someAgain )

	// Array Type : [100]int
	for index, value := range someAgain {
		fmt.Printf(" %d : %d ", index, value)
	}
										// Out Of Order Initialistion
	someAgain1 := [...]int{ 11, 22, 33, 7 : -11, 9 : - 22,  4 : 99 }
	fmt.Println("Array Length : ", len(someAgain1) )
	fmt.Printf("\nArray Type : %T \n", someAgain1 )

	// Array Type : [100]int
	for index, value := range someAgain1 {
		fmt.Printf(" %d : %d ", index, value)
	}

	aa := [2]int{ 10, 20 } 		// [2]int
	bb := [...]int{ 10, 20 } 	// [2]int
	cc := [2]int{ 10, 30 } 		// [2]int

	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	// dd := [...]int{10, 20, 2 : 0 }		// [3]int 
	// ff := [2]float32 { 10.0, 20.0 }

	// invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )

	// invalid operation: aa == ff (mismatched types [2]int and [2]float32)
	// fmt.Println( aa == ff )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): 
												// This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	// Passing Reference Of v
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	// Passing Reference Of v
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//__________________________________________________________________

// In C/C++/Java
//		By Default Arrays Are Pass By Reference

// In Go
//		By Default Arrays Are Pass By Value

func doChange1( something [5]int ) {
	for i, _ := range something {
		something[i] = 99
	}
}

// Passing Array By Reference
func doChange2( something *[5]int ) {
	for i, _ := range something {
		something[i] = 99
	}
}

//Passing Slice Of Type []int
//	Slices Are Pass By Reference
func doChange3( something []int ) {
	for i, _ := range something {
		something[i] = 99
	}
}

func printArray( something [5]int ) {
	fmt.Println()
	for i, _ := range something {
		fmt.Printf( " %d ", something[i])
	}
}

func playWithArrayAgain() {
	var a [5]int = [5]int{ 10, 20, 30, 40, 50 }

	printArray( a )
	doChange1( a )
	printArray( a )	

	printArray( a )
	doChange2( &a ) // Passing Array Reference
	printArray( a )	

	var aa [5]int = [5]int{ 10, 20, 30, 40, 50 }
	printArray( aa )
	doChange3( aa[ : ]) // Passing Array Slice
	printArray( aa )	

}

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {	
	fmt.Println("\nFunction: playWithDefaultInitialValues")
	playWithDefaultInitialValues()

	fmt.Println("\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction: playWithFlags")
	playWithFlags()

	fmt.Println("\nFunction: playWithArrayAgain")
	playWithArrayAgain()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


