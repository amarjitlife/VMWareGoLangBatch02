
package main

import (
	"fmt"
	"os"
	"bufio"
	"strings"
	"strconv"
	"encoding/json"
	"log"
)

//__________________________________________________________________

func playWithDefaultInitialValues() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 
	var c2 complex128

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

//__________________________________________________________________

// Composite Types, the molecules created by combining 
//		The basic types in various ways. 
// We'll talk about four such types
// 		arrays, structs, slices, maps

// Arrays and structs are aggregate types; 
// 		Their values are concatenations of other values in memory. 
//		Arrays are homogeneous?
//			Their elements all have the same type?
//		whereas structs are heterogeneous. 

//	Both arrays and structs are fixed size. 
//	In contrast, slices and maps are dynamic data structures that 
//		grow as values are added.

//__________________________________________________________________

func playWithArrays() {
	var a[3]int

	// range Generates Sequence Of Tuples
	//		[ (0, 0), (1, 0), (2, 0) ]
	//		Unpacking Tuple Values On index And value
	for index, value := range a { // index. value are local to loop
		fmt.Printf("\nAt Index: %d Value: %v", index, value)
	}
	fmt.Println()

	fmt.Println( a[0], a[1], a[2] )
	fmt.Println( a[ len(a) - 1] )

	// panic: runtime error: index out of range [3] with length 3
	// for i := 0 ; i < 5 ; i++ {
	// 		fmt.Printf("\nAt Index: %d Value: %v", i, a[i])		
	// }

	// range Generates Sequence Of Tuples
	//		[ (0, 0), (1, 0), (2, 0) ]
	//		Unpacking Tuple Values On _ And value
	//		_ Variable Name Means Ignore Value
	
	var aaa[3]int = [3]int{ 11, 22, 33 }
	for _, value := range aaa {
		fmt.Printf("\nValue: %v", value)
	}
	fmt.Println()

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(q) )
	for index, value := range q {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}	

	var qq = [5]int{ 10, 20, 30, 40, 50 }
	var rr = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(qq) )
	for index, value := range qq {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(rr) )
	for index, value := range rr {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}	

	s := [...]int{10, 20, 100, 111}
	// What Is Type Of s
	// 	1. Inferred From RHS
	//			RHS Type [4]int
	//	2. LHS Type Binded To [4]int
	fmt.Println("Array Length : ", len(s) )
	fmt.Printf("\nArray Type : %T \n", s )

	for index, value := range s {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	someAgain := [...]int{ 99 : -1 }
	fmt.Println("Array Length : ", len(someAgain) )
	fmt.Printf("\nArray Type : %T \n", someAgain )

	// Array Type : [100]int
	for index, value := range someAgain {
		fmt.Printf(" %d : %d ", index, value)
	}
										// Out Of Order Initialistion
	someAgain1 := [...]int{ 11, 22, 33, 7 : -11, 9 : - 22,  4 : 99 }
	fmt.Println("Array Length : ", len(someAgain1) )
	fmt.Printf("\nArray Type : %T \n", someAgain1 )

	// Array Type : [100]int
	for index, value := range someAgain1 {
		fmt.Printf(" %d : %d ", index, value)
	}

	aa := [2]int{ 10, 20 } 		// [2]int
	bb := [...]int{ 10, 20 } 	// [2]int
	cc := [2]int{ 10, 30 } 		// [2]int

	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	// dd := [...]int{10, 20, 2 : 0 }		// [3]int 
	// ff := [2]float32 { 10.0, 20.0 }

	// invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )

	// invalid operation: aa == ff (mismatched types [2]int and [2]float32)
	// fmt.Println( aa == ff )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): 
												// This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	// Passing Reference Of v
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	// Passing Reference Of v
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//__________________________________________________________________

// In C/C++/Java
//		By Default Arrays Are Pass By Reference

// In Go
//		By Default Arrays Are Pass By Value

func doChange1( something [5]int ) {
	// Full Array Get Copied
	// var something [5]int = [5]int{ 10, 20, 30, 40, 50 }

	for i, _ := range something {
		something[i] = 99
	}
}

// Passing Array By Reference
func doChange2( something *[5]int ) {
	for i, _ := range something {
		something[i] = 99
	}
}

//Passing Slice Of Type []int
//	Slices Are Pass By Reference
func doChange3( slice []int ) {
	for i, _ := range slice {
		slice[i] = 99
	}
}

func printArray( something [5]int ) {
	fmt.Println()
	for i, _ := range something {
		fmt.Printf( " %d ", something[i])
	}
}

func playWithArrayAgain() {
	var a [5]int = [5]int{ 10, 20, 30, 40, 50 }

	printArray( a )
	doChange1( a )
	printArray( a )	

	printArray( a )
	doChange2( &a ) // Passing Array Reference
	printArray( a )	

	var aa [5]int = [5]int{ 10, 20, 30, 40, 50 }
	printArray( aa )
	doChange3( aa[ : ]) // Passing Array Slice
	printArray( aa )	

}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithSlices() {
	months := [...]string{ 0: "", "Jan", "Feb", "Mar", "Apr", "May",
						"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}

	fmt.Println("Months : ", months )

	// Slices
	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer  := months[ 2 : 7 ]

	fmt.Println("Quater1 : ", quater1 )
	fmt.Println("Quater2 : ", quater2 )
	fmt.Println("Summer  : ", summer )

	// Iterating On Slices
	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Appears In Both \n", s)
			}
		}
	}

	fmt.Printf("Array Slices Type: %T %T %T", quater1, quater2, summer)
	// Array Slices Type: []string []string []string

	greeting 		:= "Good Evening! Good"

	// Slices Syntax But Giving Substrings Of string Type
	first 	:= greeting[ 1 : 4 ]
	last  	:= greeting[ 5 :   ]
	between := greeting[ 2 : 6 ]

	fmt.Println( greeting )
	fmt.Println( first )
	fmt.Println( last )
	fmt.Println( between )

	fmt.Println( first == last, first == between )

	firstGood := greeting[ : 4 ]
	lastGood  := greeting[ len(greeting) - 4 :  ]
	
	fmt.Printf("String Slices Type : %T %T\n", firstGood, lastGood )

	fmt.Println( firstGood, lastGood, len( firstGood ), len( lastGood ) )
	fmt.Println( firstGood == lastGood )
}

//__________________________________________________________________________________
// 						
// 								GO SLICES CONCEPTS
//__________________________________________________________________________________

// Slices represent variable-length sequences whose elements all have the same type. 
// A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence 
// (or perhaps all) of the elements of an array, which is known as the slice?s 
// underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable 
// 			through the slice, which is not necessarily the array?s first element. 
// 		The length is the number of slice elements; it can?t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

//  The slice operator s[ i : j ], where 0 <= i <= j <= cap(s), 

// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 		which may be an array variable, a pointer to an array, or another slice. 

// 	The resulting slice has j-i elements. 
// 	If i is omitted,it's 0,and if j is omitted, it's len(s). 

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func reverse( slice []int ) {
	for i, j := 0, len(slice) - 1  ;  i < j  ;  i, j = i + 1, j - 1 {
		slice[i], slice[j] = slice[j], slice[i]
	}
}

// Following Function Takes Argument:
//		Passing Array Slice
// Slices Are Pass By Reference
func doChangeAgain4( slice []int ) {
	for i, _ := range slice {
		slice[i] = 111
	}
}

func slicesEqual( x, y []int ) bool {
	if len( x ) != len ( y ) { return false }

	for i := range x {
		if x[i] != y[i] { return false }
	}
	return true
}

func playWithArrayAndSlices() {
	a := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 99 }
	fmt.Printf("\nType Of a: %T", a )
	// [9]int

	fmt.Println( a )
	reverse( a[ : ] )
	fmt.Println( a )

	// Creating Slice Using Literal Syntax
	// s Is A Slice
	//		Array Syntax Without Size Information
	s := []int { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }

	fmt.Println( s )
	// s[ : 5 ] Is Slice Over A Slice s 
	reverse( s[ : 5 ] )
	fmt.Println( s )
	reverse( s[ 5 :  ] )
	fmt.Println( s )

	doChangeAgain4( s[ 3 : 6 ] )
	fmt.Println( s )

	slice1 := a[ 2 : 6 ]
	slice2 := a[ 2 : 6 ]
	slice3 := a[ 5 : 8 ]

	// fmt.Println( slice1 == slice2 )
	// fmt.Println( slice1 == slice3 )

	fmt.Println( slicesEqual( slice1, slice2 ) )
	fmt.Println( slicesEqual( slice1, slice3 ) )
	fmt.Println( slicesEqual( slice2, slice3 ) )

	// greeting := "Good Morning! Good Good!!!"
	// var ss []string = greeting[ : ]
}

//__________________________________________________________________

func playWithSlicesFunctions() {
// The built-in function make creates a slice of a specified element 
// 		type, length, and capacity.

// The capacity argument may be omitted, in which case the capacity 
//   equals the length.
// 		make([]T, len)
// 		make([]T, len, cap) // same as make([]T, cap)[:len]

	// Background Array OF Size 3 Allocated
	s := make( []string, 3 )

	fmt.Println("Empty Slice : ", s)
	fmt.Printf("Slice Type:  %T \n", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s[0] = "a"
	s[1] = "b"
	s[2] = "c"

	fmt.Println("Slice Value:", s)
	fmt.Println("Slice Element: ", s[2] )

	s = append( s, "d" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s = append( s, "E", "F", "G", "H" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s = append( s, "dd", "EE", "FF" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	s = append( s, "d", "E", "F", "G", "H", "1", "2", "3", "4" )
	fmt.Println("Slice Value:", s)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(s), cap(s))

	//______________________________________________________________

	ss := make( []string, 3 )

	fmt.Println("Slice Value:", ss)
	fmt.Printf("Slice Type:  %T \n", ss)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(ss), cap(ss))

	ss[0] = "AA"
	ss[1] = "BB"
	ss[2] = "CC"
	fmt.Println("Slice Value:", ss)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(ss), cap(ss))

	cc := make( []string, len( ss ) )
	fmt.Println("Slice Value:", cc)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(cc), cap(cc))

	// Shallow Copy
	cc = ss // Reference Assignment
	fmt.Println("Slice Value:", ss)
	fmt.Println("Slice Value:", cc)

	ss[0] = "Hello!"
	fmt.Println("Slice Value:", ss)
	fmt.Println("Slice Value:", cc)

	ss = append(ss, "GG", "HH" )
	fmt.Println("Slice Value:", ss)
	fmt.Println("Slice Value:", cc)
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(ss), cap(ss))
	fmt.Printf("Slice Length:  %d  Capacity : %d\n", len(cc), cap(cc))

	//______________________________________________________________

	sss := make( []string, 0 )

	fmt.Println(">>> sss Slice: ",  sss )
	// fmt.Println(">>>>ss Slice Element ss[0]: ",  ss[0] )

	sss = append( sss, "AA", "BB", "CC", "DD", "EE", "FF")
	ccc := make( []string, len( sss ) )

	fmt.Println("sss Slice: ",  sss )
	fmt.Println("ccc Slice: ",  ccc )

	// Deep Copy
	//		Full Object Get Copied
	copy( ccc, sss )
	fmt.Println("sss Slice: ",  sss )
	fmt.Println("ccc Slice: ",  ccc )

	sss[0] = "Good Morning!!!"
	fmt.Println("sss Slice: ",  sss )
	fmt.Println("ccc Slice: ",  ccc )

	tt := []string{ "Ding", "Dong", "Ming", "Mong" }
	fmt.Println("tt Slice: ",  tt )
	fmt.Printf("tt Slice Type : %T",  tt )
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func appendInt( x []int, y int  ) []int {
	var z []int

	zlen := len( x ) + 1
	if zlen <= cap( x ) { // Append Data In Pool 
		z = x[ : zlen ]
	} else { // Underlinding Array Is Full
		// When Array Is FUll, Allocat A Ne Array
		//		To Additional Data
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * len( x ) // Pool Size Increased: Double
		}

		// Creating New Slice With Underlining New Array Of Double Size
		z = make( []int, zlen, zcap )
	}

	z[ len( x ) ] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendInt( x, i )
		fmt.Printf(" %d Capacity = %d \t %v \n", i, cap( y ), y )
		x = y
	}
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithReadingInputs() {
	input := bufio.NewScanner( os.Stdin )

	outer: 
		for input.Scan() {
			var ints []int

			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt(s, 10, 64 )

				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer
				}
				ints = append( ints, int(x) )
			}

			fmt.Printf("%v\n", ints)
			reverse(ints)
			fmt.Printf("%v\n", ints)
		}
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWith2DimentionalData() {
	twoDimentionalArray := make( [][]int, 3 )

	for i := 0 ; i < 3 ; i++ {
		innerLen := i + 1

		twoDimentionalArray[ i ] = make( []int, innerLen ) 
		for j := 0 ; j < innerLen ; j++ {
			twoDimentionalArray[i][j] = i + j
		}
	}

	fmt.Println("2 Dimentional Array:", twoDimentionalArray )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Polymorphic Function
//		Mechanism : Variadic Arguments

// Function With Varidiac Arguments
//		Variable Number Of Arguments
func summation( numbers ...int ) int {
	fmt.Printf("\t %v \t %T\n", numbers, numbers )

	total := 0
	for _, number := range numbers {
		total = total + number
	}

	return total
}

func playWithSummation() {
	var result int

	result = summation() 
	fmt.Println("Result : ", result)

	result = summation(11) 
	fmt.Println("Result : ", result)

	result = summation(10, 20, 30, 40) 
	fmt.Println("Result : ", result)

	result = summation(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) 
	fmt.Println("Result : ", result)
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func appendSlice( x []int, y ...int ) []int {
	var z []int

	zlen := len(x) + len( y )
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Array Is Full, Allocate A New Array
		//	To Append Additional Data
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x) 	// Pool Size Increased
		}
		
		z = make( []int, zlen, zcap )
		copy(z, x)
	}
	copy( z[ len(x) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x , 10, 20, 30 )
	fmt.Println( x )

	x = appendSlice(x , 11, 22, 33, 44, 55, 66 )
	fmt.Println( x )

	numebrs := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	x = appendSlice( x, numebrs... )
	fmt.Println( x )	
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func filterEmpty( strings []string ) []string {
	i := 0
	for _, s := range strings {
		if s != "" {
			strings[i] = s
			i++
		}
	}
	return strings[ : i ]
}

func filterEmptyAgain( strings []string ) []string {
	out := strings[ : 0 ] // Zero Length Slice Of Original
	for _, s := range strings {
		if s != "" {
			out = append( out, s )
		}
	}
	return out
}

func playWithNonEmpty() {
	data := []string{ "one", "", "two", "ding", "", "ting" }
	fmt.Printf("%q \n", data)	
	filteredData := filterEmpty( data )
	fmt.Printf("%q \n", filteredData )

	dataAgain := []string{ "111", "", "", "9999", "", "Data", "" }
	fmt.Printf("%q \n", dataAgain)	
	filteredDataAgain := filterEmptyAgain( dataAgain )	
	fmt.Printf("%q \n", filteredDataAgain )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithMaps() {
	m := make( map[string]int )

	m["k1"] = 7
	m["k2"] = 13

	fmt.Println("Map: ", m )
	fmt.Println("Map Length: ", len( m ) )

	v1, status1 := m["k1"]
	fmt.Println("Value Status1: ", v1, status1 )

	delete(m, "k2")
	fmt.Println("Map: ", m )
	fmt.Println("Map Length: ", len( m ) )

	value, status := m["k2"]
	// BEST PRACTICE
	//		Always Check status
	if status != false {
		fmt.Println("Map Value Status: ", value, status )	
	} else {
		fmt.Println("Key Doesn't Exists")
	}

	mm := map[string]int{ "foo": 10, "bar": 20 }
	fmt.Println("Map: ", mm )	
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func removeDuplicates() {
	seen := make( map[string]bool ) // a set of strings
	input := bufio.NewScanner( os.Stdin )

	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			// fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}

	fmt.Println( seen )	
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Circle struct {
	X, Y, Radius int
}

type Wheel struct {
	X, Y, Radius, Spokes int
}


func playWithCircleAndWheel() {
	var c Circle
	c.X = 10
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle :", c)

	var w Wheel
	w.X = 11
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24
	fmt.Println("Wheel :", w)
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Point1 struct {
	X int
	Y int
}

type Circle1 struct {
	Center Point1 	//Creating Object Of Another Type
	Radius int
}

type Wheel1 struct {
	Circle Circle1 //Creating Object Of Another Type
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1 // c Is Instance Of Circle1 Type
	c.Center.X = 10
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle1 :", c)

	var w Wheel1 // w Is Instance Of Wheel1 Type
	w.Circle.Center.X = 11
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24
	fmt.Println("Wheel1 :", w)
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Point struct {
	X int
	Y int
}

func ScalePoint( point Point, factor int ) Point {
	return Point{ point.X * factor, point.Y * factor }
}

func AddPoints( point1 Point, point2 Point ) Point {
	var xx = point1.X + point2.X 
	var yy = point1.Y + point2.Y 

	return Point{ xx, yy }
}

func playWithPointType() {
	point1 := Point{ 10, 20 }
	point2 := Point{ 100, 200 }
	point3 := Point{ 10, 20 }
	point4 := Point{ 1000, 2000 }

	fmt.Println("point1 : ", point1)
	fmt.Println("point2 : ", point2)
	fmt.Println("point3 : ", point3)

	fmt.Println( point1 == point2 )
	fmt.Println( point1 == point3 )

	var point5 = ScalePoint( point1, 5 )
	var point6 = ScalePoint( point2, 10 )
	fmt.Println("point5 : ", point5)
	fmt.Println("point6 : ", point6)

	point7 := AddPoints( point1, point2 )
	point8 := AddPoints( point3, point4 )

	fmt.Println("point7 : ", point7)
	fmt.Println("point8 : ", point8)
}


//__________________________________________________________________

// In GO
//		By Default Struct Objects Are Pass By Value

// In Java/Python
//		By Default Class Objects Are Pass By Reference

func doChangeAgain5( point Point ) {
	point.X = 99
	point.Y = 99
}

// Passing Point Type Object Using Pass By Reference
func doChangeOnceAgain( point * Point ) {
	point.X = 99
	point.Y = 99
}

func playWithDoChangeAgain() {
	point1 := Point{ 10, 20 }

	fmt.Println("point1 : ", point1)
	doChangeAgain5( point1 )	
	fmt.Println("point1 : ", point1)

	point2 := Point{ 11, 22 }
	fmt.Println("point2 : ", point2)
	doChangeOnceAgain( &point2 )	// Passing Reference Of point2 Object
	fmt.Println("point2 : ", point2)
}

//__________________________________________________________________

type Point2 struct {
	X int
	Y int
}

type Circle2 struct {
	// Center Point2 //Creating Object Of Another Type
	Point2 			 //Structure Embedding 
	Radius int
}

type Wheel2 struct {
	// Circle Circle2 //Creating Object Of Another Type
	Circle2 		  //Structure Embedding 
	Spokes int
}

func playWithCircle2AndWheel2() {
	var c Circle2 // c Is Instance Of Circle2 Type
	c.Point2.X = 10
	c.Point2.Y = 20
	c.Radius = 50

	fmt.Println("Circle2 :", c)

	// // Can Access Directly Members Of Embedded Structure
	c.X = 100
	c.Y = 200
	c.Radius = 500
	fmt.Println("Circle2 :", c)

	var w Wheel2 // w Is Instance Of Wheel2 Type
	w.Circle2.Point2.X = 11
	w.Circle2.Point2.Y = 22
	w.Circle2.Radius = 55
	w.Spokes = 24
	fmt.Println("Wheel2 :", w)

	// Can Access Directly Members Of Embedded Structure
	w.X = 111
	w.Y = 222
	w.Radius = 555
	w.Spokes = 444
	fmt.Println("Wheel2 :", w)

	var ww Wheel2

	ww = Wheel2{ Circle2{ Point2{ 88, 99}, 77 }, 44 }
	fmt.Println("Wheel2 ww:", ww)


	ww = Wheel2{ 
			Circle2 : Circle2 { 
				Point2 : Point2{ 888, 999}, 
				Radius : 777,
			}, 
			Spokes: 444,
		}
	fmt.Println("Wheel2 ww:", ww)
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Movie struct {
	Title string
	Year int 		`json:"Release Year"`
	Color bool 		`json:"Movie Color"`
	Actors []string
}

func playWithMoviesMarshallingAndUnmarshalling() {

	var movies = []Movie {
		{
			Title: "Shole",
			Year: 1980,
			Color: true,
			Actors: []string {
				"Dharam Paaji",
				"Amitaab",
				"Basanti",
				"Gabbar Singh",
			},
		},
		{
			Title: "Bajarangi Bhaijaan",
			Year: 2010,
			Color: true,
			Actors: []string {
				"Salman Khan",
				"Nawajudin Sidqui",
				"Little Girl",
			},
		},
		{
			Title: "Mugle Azaam",
			Year: 1960,
			Color: true,
			Actors: []string {
				"Madhu Bala",
				"Dilip Kumar",
				"Prithi Raj",
			},
		},
		{
			Title: "Ding Dong",
			Year: 2000,
			Color: false,
			Actors: []string {
				"AAAA",
				"BBBB",
				"CCCCC",
				"DDDDDD",
			},
		},
	}

	for index, movie := range movies {
		fmt.Println( index, movie )
	}

	{
		jsonData, error := json.Marshal( movies )
		if error != nil{
			log.Fatalf("JSON Marshlling Failed... %s", error )
		}

		fmt.Printf("JSON DATA: \n %s \n", jsonData)
	}

	jsonData, error := json.MarshalIndent( movies, "", "	" )
	if error != nil{
		log.Fatalf("JSON Marshlling Failed... %s", error )
	}

	fmt.Printf("JSON DATA: \n %s \n", jsonData)

	var moviesTitle []struct { Title string }

	if error := json.Unmarshal( jsonData, &moviesTitle ) ; error != nil {
		log.Fatalf("JSON UNMarshlling Failed... %s", error )
	} 

	fmt.Printf("UNMARSHLLED DATA: \n %s \n", moviesTitle)

	var moviesAgain []Movie

	if error := json.Unmarshal( jsonData, &moviesAgain ) ; error != nil {
		log.Fatalf("JSON UNMarshlling Failed... %s", error )
	} 

	fmt.Printf("UNMARSHLLED DATA: \n")
	fmt.Println( moviesAgain)
}

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {	
	fmt.Println("\nFunction: playWithDefaultInitialValues")
	playWithDefaultInitialValues()

	fmt.Println("\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction: playWithFlags")
	playWithFlags()

	fmt.Println("\nFunction: playWithArrayAgain")
	playWithArrayAgain()

	fmt.Println("\nFunction: playWithSlices")
	playWithSlices()

	fmt.Println("\nFunction: playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction: playWithSlicesFunctions")
	playWithSlicesFunctions()

	fmt.Println("\nFunction: playWithAppendInt")
	playWithAppendInt()

	// fmt.Println("\nFunction: playWithReadingInputs")
	// playWithReadingInputs()

	fmt.Println("\nFunction: playWith2DimentionalData")
	playWith2DimentionalData()

	fmt.Println("\nFunction: playWithSummation")
	playWithSummation()

	fmt.Println("\nFunction: playWithAppendSlices")
	playWithAppendSlices()

	fmt.Println("\nFunction: playWithNonEmpty")
	playWithNonEmpty()

	fmt.Println("\nFunction: playWithMaps")
	playWithMaps()

	// fmt.Println("\nFunction: removeDuplicates")
	// removeDuplicates()

	fmt.Println("\nFunction: playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\nFunction: playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\nFunction: playWithPointType")
	playWithPointType()

	fmt.Println("\nFunction: playWithDoChangeAgain")
	playWithDoChangeAgain()

	fmt.Println("\nFunction: playWithCircle2AndWheel2")
	playWithCircle2AndWheel2()

	fmt.Println("\nFunction: playWithMoviesMarshallingAndUnmarshalling")
	playWithMoviesMarshallingAndUnmarshalling()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

