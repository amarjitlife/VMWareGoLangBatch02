

package main

import (
	"fmt"
	"math"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func division(dividend, divisor int ) ( int, int ) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, 0
}
											// Labeled Tuple
func divisionAgain(dividend, divisor int ) ( quotient int, remainder int ) {	
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, 0
}

var xx int = 100

func playWithDivision() {
	q, r := division( 10, 3 )

	fmt.Printf("\nquotient: %d remainder: %d", q, r)

	qq, rr := divisionAgain( 10, 3 )
	fmt.Printf("\nquotient: %d remainder: %d", qq, rr)

	fmt.Println( xx )
}

//__________________________________________________________________


func playWithClosures() { // Enclosing Context
	var x, y = 30, 10

	// Anonyoums Functions
	// Closure/Lambda Expression
	add := func (x, y int) int { return x + y }
	sub := func (x, y int) int { return x - y }

	result := add(x, y)
	fmt.Println("Result : ", result)

	result = sub(x, y)
	fmt.Println("Result : ", result)

	// ___________________________________
	start := 0


	incrementBy7 := func() int { //Enclosed Context
		//Enclosed Context Can Access Enclosing Context
		start = start + 7
		return start
	}

	incrementBy10 := func() int {
		start = start + 10
		return start
	}

	result = incrementBy7()
	fmt.Println("Result +7: ", result)

	result = incrementBy7()
	fmt.Println("Result +7: ", result)

	result = incrementBy7()
	fmt.Println("Result +7: ", result)

	result = incrementBy10()
	fmt.Println("Result +10: ", result)

	result = incrementBy10()
	fmt.Println("Result +10: ", result)

	// Result +7:  7
	// Result +7:  14
	// Result +7:  21
	// Result +10:  31
	// Result +10:  41

	start = 0

	iincrementBy7 := func() {
		start = start + 7
	}

	iincrementBy10 := func() {
		start = start + 10
	}

	iincrementBy7()
	fmt.Println("Result +7: ", start)

	iincrementBy7()
	fmt.Println("Result +7: ", start)

	iincrementBy7()
	fmt.Println("Result +7: ", start)

	iincrementBy10()
	fmt.Println("Result +10: ", start)

	iincrementBy10()
	fmt.Println("Result +10: ", start)
}

//__________________________________________________________________

// Higher Order Functions
//		Functions Which Takes Functions As Arguments And/Or Return Functions

// Function Type
//		func (int, int) -> int
func mul(x, y int) int { return x * y }
func div(x, y int) int { return x / y }

// Polymorphic Functions
// Function Type
//		func (int, int, func(int, int) int ) int
func calculator(x, y int, operation func(int, int) int ) int {
	return operation(x , y )
}

func playWithFunctionsAndClosures() {
	var x, y = 40, 20
	var result int

	// Function Type
	//		func (int, int) -> int
	// Closure/Lambda Expression
	add := func (x, y int) int { return x + y }
	sub := func (x, y int) int { return x - y }

	result = calculator(x, y, add)
	fmt.Println("Result : ", result)

	result = calculator(x, y, sub)
	fmt.Println("Result : ", result)

	result = calculator(x, y, mul)
	fmt.Println("Result : ", result)

	result = calculator(x, y, div)
	fmt.Println("Result : ", result)

// Function : playWithFunctionsAndClosures
// Result :  60
// Result :  20
// Result :  800
// Result :  2
	// var something func (int, int) int = mul
	// result = something(100, 200)
	// fmt.Println("Result : ", result)	

	// var somethingAgain = calculator
	// result = somethingAgain(100, 200, add)
	// fmt.Println("Result : ", result)		
}

//__________________________________________________________________

// Higher Order Function
//		Function Returning Function
func Sphere() func (radius float64) float64 {
	
					 // Function Type
					 //		func ( float64 ) float64 
	volumeFunction := func( radius float64) float64 {
		volume := 4/3 * math.Pi * radius * radius * radius
		return volume
	}

	return volumeFunction
}

func playWithSphereFunction() {

	 // Function Type
	 //		func ( float64 ) float64 
	sphereVolume := Sphere()

	result := sphereVolume( 5 )
	fmt.Println("Result : ", result)		

	result = sphereVolume( 10 )
	fmt.Println("Result : ", result)			

	 // Function Type
	 //		func () func ( float64 ) float64 

	sphereAgain := Sphere
	fmt.Printf("Type : %T", sphereAgain )
}


//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!


func firstFunction() {
	fmt.Println("First Function Called...")
}

func secondFunction() {
	fmt.Println("Second Function Called...")	
}

func doSomething() (i int) {
	defer func() { i++ }()
	return 1
} // defer Marked Functions Will Be Called Just Before Exit Of The Enclosing Context

func playWithDoSomethingFunction() { // Enclosing Context
	// file := fopen()
	// defer file.close()
	defer firstFunction()
	// firstFunction()
	secondFunction()

	result := doSomething()
	fmt.Println("Result : ", result)			

	// Use Case Of defer Keyword Use
	// file := File.open("test.txt")
	// defer file.close()
	//read file content....

} // defer Marked Functions Will Be Called Just Before Exit Of The Enclosing Context

// First Function Called...
// Second Function Called...

// Second Function Called...
// First Function Called...

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithDivision")
	playWithDivision()

	fmt.Println("\nFunction : playWithClosures")
	playWithClosures()

	fmt.Println("\nFunction : playWithFunctionsAndClosures")
	playWithFunctionsAndClosures()

	fmt.Println("\nFunction : playWithSphereFunction")
	playWithSphereFunction()

	fmt.Println("\nFunction : playWithDoSomethingFunction")
	playWithDoSomethingFunction()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}
