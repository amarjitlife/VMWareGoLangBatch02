______________________________________________________________

DAY 01
______________________________________________________________

	ASSSIGNMENT 01: READING AND REASONING ASSIGNMENT
		Chapter 05 : Pointers and Arrays [ MUST MUST ]
		Chapter 02 : Types, Operators and Expressions [ MUST ]
		
			The C Programming Language 2nd Edition 
				By Brian Kernigham and Dennis Ritchie

______________________________________________________________

DAY 02
______________________________________________________________

	ASSSIGNMENT 00: EXPERIMENT AND EXPLORE GO CODE
		Experiment and Explore Go Code Till Now Done!

	ASSSIGNMENT 01: READING AND REASONING ASSIGNMENT
		Chapter 05 : Pointers and Arrays [ MUST MUST ]
		
			The C Programming Language 2nd Edition 
				By Brian Kernigham and Dennis Ritchie

	ASSSIGNMENT 02: READING AND EXPLORATION ASSIGNMENT FROM GO DOCUMENTATION
		Reference Link
			https://go.dev/ref/spec
			https://pkg.go.dev/strings
			https://pkg.go.dev/fmt


	ASSSIGNMENT 03: THINKING, EXPLORATION REASONING ASSIGNMENT
		1. How Floating Points Are Stored in C/C++/Java/Python and Go
		2. How Divide By Zero Dealt in C/C++/Java/Python and Go
		3. How Infinity Are Treated In C/C++/Java/Python and Go
		4. How NaN Are Treated In C/C++/Java/Python and Go

		Following Java Code: What Will Be Output?
	        System.out.println(1.0 / 0.0); 
	        System.out.println(-1.0 / 0.0);
	        System.out.println(0.0 / 0.0);
	        
	        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
	        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);

	        System.out.println(0.0 / 0.0 == Double.NaN);
	        System.out.println(2.0 - 1.1);        

______________________________________________________________

DAY 03
______________________________________________________________


______________________________________________________________
______________________________________________________________
______________________________________________________________
______________________________________________________________
______________________________________________________________
