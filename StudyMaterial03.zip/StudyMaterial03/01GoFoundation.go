/*
Process 01
	To Build Go Program
		go build 01GoFoundation.go

	To Run Go Compiled Program
		./01GoFoundation

Process 02
	To Run Go Program
		go run 01GoFoundation.go
*/
package main

// import "fmt"
// import "os"

import (
	"fmt"
	"os"
	"time"
)

//______________________________________________________

// Function Which Takes No Argument And Doesn't Return Anything
func helloWorld() {
	fmt.Println("Hello World!")
}

//______________________________________________________

const boilingPointF = 212.0

// Function Which Takes One Argument Of Type float64
/// And Returns One VAlue OF float64 Type
func fToC( f float64 ) float64 {
	return ( f - 32 ) * 5 / 9
}

func playWithConstantVariables() {
	// Mutable

	// In GO Language Type Inferencing and Binding
	//		Happens At COMPILE TIME
	// 		1. Type Inferencing From RHS Value
	//		2. Inferred Type Binded With LHS Identifier

	// In Python/JS Language Type Inferencing and Binding
	//		Happens At RUN TIME
	// 		1. Type Inferencing From RHS Value
	//		2. Inferred Type Binded With LHS Identifier

	var f = boilingPointF
	var c = ( f  - 32 ) * 5 / 9 

	fmt.Printf("Boiling Point: %g, Farentheit: %g", f, c )
	// Immutable
	const freezingF, boilingF = 32.0, 212.0 // Local To Function

	fmt.Printf("%g Farentheit: %g Centrigrade", freezingF, fToC( freezingF ) )
	fmt.Printf("%g Farentheit: %g Centrigrade", boilingF, fToC( boilingF ) )

	// expecting type
	// var something
	// Explicitly Add Type
	// Implicitly Inferred From RHS
	var something int 

	//In Java/C/C++
	//	In Java By Default Variables
	// 	int something;
	fmt.Println( something )
}

//______________________________________________________
// syntax error: non-declaration statement outside function body
// 		kk := 3

var kk1 = 3

func playWithDataTypes() {
	// Safety : 
	//		BEST PRACTICE:
	//		All Variable Must Be Initialsed To Default Values
	var c, python, java bool
	var i int

	// Following Both Are Equivalent
	var ii, jj int = 10, 20

	// 1. Type Infererencing From RHS
	//		From RHS Expression
	// 2. Type Binding With LHS
	//		Bind The Inferred Type With LHS
	// Both Type Inferrencing and Binding Happens At Compile Time
	var iii, jjj = 10, 20

	fmt.Println(c, python, java, i )
	fmt.Println( ii, jj )
	fmt.Println( iii, jjj )

//	Short Cut Notation Syntax
//		Similar To Python Style Syntax
// 		Both Type Inferrencing and Binding Happens 
//			At Compile Time Only
	k := 3
	some, some1, something := true, false, "Good Afternoon!"
	fmt.Println( k, some, some1, something )
	k = 111
	fmt.Println( k, some, some1, something )

// Compiler : Usage Analysis
//		Deeper Analysis
}

//______________________________________________________

// DESIGN PRINCIPLE
//		Type Safety Is Paramount
//		Strict Type System

// Domain Knowledge
type Celsius 	float64
type Fahrenheit float64

// func fToC( f float64 ) float64 { }

// FOLLOWING CODE BETTER DESIGN
//		Follows Type Safety

// Celsius And Fahrenheit Are Type Of Type float64
// 		Type Aliases Can Be Used Wherever float64 Used
//		Creating It To Express Domain Knolegedge
//		To Improve Code Readibility

// Naming Conventions For Identifiers
//		Generally Identifiers Follows Camel Cases With First Word In Small
//		Identifiers First Alphabet Is Small
//			These Are Locals/Private To Pacakage
//		Identifiers First Alphabet Is Capital
//			These Are Exported From Pacakage

func FToC( f Fahrenheit ) Celsius { return Celsius( ( f  - 32 ) * 5 / 9  )  }
func CToF( c Celsius ) Fahrenheit { return Fahrenheit( ( c * 9 / 5 + 9  ) ) }

// FOllowing Both Definations Are Equivalent
// const	BoilingC Celsius = 100.0
// const	FreezingC Celsius = 0.0
// const	AbsoluteZeroC Celsius  = -273.15
// const	FreezingF Fahrenheit = 0.0

// Mutliple Constant Creation
const (
	BoilingC Celsius = 100.0
	FreezingC Celsius = 0.0
	AbsoluteZeroC Celsius  = -273.15
	FreezingF Fahrenheit = 0.0
)

func playWithConstants() {
	boilingF := CToF( BoilingC )

	fmt.Printf("\n %g", boilingF - CToF( FreezingC) )
	fmt.Printf("\n %g", boilingF )

	fmt.Printf("\n %g", BoilingC + FreezingC )

	// invalid operation: BoilingC + FreezingF 
	//		(mismatched types Celsius and Fahrenheit)
	// fmt.Printf("\n %g", BoilingC + FreezingF )

	// var someTemperator float64 = 90.90

	// invalid operation: BoilingC + someTemperator 
	// 		(mismatched types Celsius and float64
	// fmt.Printf("\n %g", BoilingC + someTemperator )
}

//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithForLoop( args []string ) {
	var s, sep string

	sep = "\n"
	for i := 0 ; i < len( args ) ; i++ {
		// i Is Defined Local To For Loop Context
		//	:= Operator Designed To Be Used In Local Context
		s += sep + args[i]
	}

	fmt.Println( s )
	// fmt.Println( i )
}

//__________________________________________________________________

func playWithFormatSpecifiers() {
	c := FToC( 212.0 )

	fmt.Println( c )

	fmt.Printf("\n %v", c )
	fmt.Printf("\n %f", c )
	fmt.Printf("\n %g", c )
	fmt.Printf("\n %e", c )
}


// General:
// %v	the value in a default format
// 			when printing structs, the plus flag (%+v) adds field names
// %#v	a Go-syntax representation of the value
// %T	a Go-syntax representation of the type of the value
// %%	a literal percent sign; consumes no value

// Boolean:
// %t	the word true or false


// Integer:

// %b	base 2
// %c	the character represented by the corresponding Unicode code point
// %d	base 10
// %o	base 8
// %O	base 8 with 0o prefix
// %q	a single-quoted character literal safely escaped with Go syntax.
// %x	base 16, with lower-case letters for a-f
// %X	base 16, with upper-case letters for A-F
// %U	Unicode format: U+1234; same as "U+%04X"

// Floating-point and complex constituents:

// %b	decimalless scientific notation with exponent a power of two,
// 	in the manner of strconv.FormatFloat with the 'b' format,
// 	e.g. -123456p-78
// %e	scientific notation, e.g. -1.234456e+78
// %E	scientific notation, e.g. -1.234456E+78
// %f	decimal point but no exponent, e.g. 123.456
// %F	synonym for %f
// %g	%e for large exponents, %f otherwise. Precision is discussed below.
// %G	%E for large exponents, %F otherwise
// %x	hexadecimal notation (with decimal power of two exponent), e.g. -0x1.23abcp+20
// %X	upper-case hexadecimal notation, e.g. -0X1.23ABCP+20


// REFER FOLLOWING LINK
// 		https://pkg.go.dev/fmt


//__________________________________________________________________

// Type System Completeness

func playWithIfElse() {
	var x int = -10

// ./01GoFoundation.go:251:5: non-boolean condition in if statement
	// if ( x ) {
	// if  x  {

	// IN GO
	//		EXPRESSION CAN BE ANY WHICH EVALUATES TO bool Value

	// IN C/C++
	//		EXPRESSION CAN BE ANY WHICH EVALUATES TO int Value

	// if ( EXPRESSION ) { } else { }
	if  x == -10  {
		fmt.Println("Oyee Oyeee")
	} else {
		fmt.Println("Hoyeee Hoyeee")
	}
}

// BEST PRACTICES
// Special Function
//		Role To Do Type Conversion
//		Value Conversion
//	2 Step Process
//		1. Do Type Conversion
//		2. Then Value Conversion
func btoi( b bool ) int {
	if b { return 1 }
	return 0
}

func itob( i int ) bool { return i != 0 }

func playWithIfElseAgain() {
	var x int = -10
	// IN GO
	//		EXPRESSION CAN BE ANY WHICH EVALUATES TO bool Value

	if itob( x ) {
		fmt.Println("Oyee Oyeee")
	} else {
		fmt.Println("Hoyeee Hoyeee")
	}
}

//__________________________________________________________________

func playWithSwitch() {
	i := 2

	switch i {
	case 1:
		fmt.Println("One")
	case 2:
		fmt.Println("Two")
	case 3:
		fmt.Println("Three")
	}

	switch time.Now().Weekday() { // break Is Implicit
	case time.Saturday, time.Sunday: // , Seperated List Means OR
		fmt.Println("Weekend")
	default: // Default Case Optional
		fmt.Println("Weekday")
	}

	t := time.Now()

	switch { // Pattern Matching
	case t.Hour() < 12:
		fmt.Println("Before Noon")
	default:
		fmt.Println("After Noon")		
	}
}

// EXPERIMENT ABOVE CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!
//__________________________________________________________________

func playWithTypeConversion() {
	var i, j int = 10, 10

	const (
		cells = 100 		// untyped int OR assumed type int
		xyrange = 30.0
	)

// ./01GoFoundation.go:346:31: 0.5 (untyped float constant) truncated to int
// ./01GoFoundation.go:347:31: 0.5 (untyped float constant) truncated to int
	// x := xyrange * ( i / cells - 0.5 )
	// y := xyrange * ( j / cells - 0.5 )
	x := xyrange * ( float64( i ) / cells - 0.5 )
	y := xyrange * ( float64( j ) / cells - 0.5 )

	fmt.Printf("\n Values: %v %v", x, y )
	
	var ii, jj int = 10, 10
	var	cells1 int = 100
	var	xyrange1 float64 = 30.0

// ./01GoFoundation.go:360:21: invalid operation: float64(ii) / cells1 (mismatched types float64 and int)
// ./01GoFoundation.go:361:21: invalid operation: float64(jj) / cells1 (mismatched types float64 and int)
	// xx := xyrange1 * ( float64( ii ) / cells1 - 0.5 )
	// yy := xyrange1 * ( float64( jj ) / cells1 - 0.5 )

	xx := xyrange1 * ( float64( ii ) / float64( cells1 ) - 0.5 )
	yy := xyrange1 * ( float64( jj ) / float64( cells1 ) - 0.5 )

	fmt.Printf("\n Values: %v %v", xx, yy )
}

// Constant Folding
// 		Constant Expression Evaluation At Compile Time

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction: helloWorld")
	helloWorld()	

	fmt.Println("\nFunction: playWithConstantVariables")
	playWithConstantVariables()

	fmt.Println("\nFunction: playWithDataTypes")
	playWithDataTypes();

	fmt.Println("\nFunction: playWithConstants")
	playWithConstants()

	fmt.Println("\nFunction: playWithForLoop")
	playWithForLoop( os.Args )

	fmt.Println("\nFunction: playWithFormatSpecifiers")
	playWithFormatSpecifiers()

	fmt.Println("\nFunction: playWithIfElse")
	playWithIfElse()

	fmt.Println("\nFunction: playWithIfElseAgain")
	playWithIfElseAgain()

	fmt.Println("\nFunction: playWithSwitch")
	playWithSwitch()

	fmt.Println("\nFunction: playWithTypeConversion")
	playWithTypeConversion()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


