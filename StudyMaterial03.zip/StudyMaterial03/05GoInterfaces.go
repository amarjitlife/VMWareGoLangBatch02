package main

import (
	"fmt"
	"math"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// DUCK TYPING
// 		Duck typing in computer programming is an application of the duck test?
// 		"If it walks like a duck and 
//		 it quacks like a duck, 
//		 then it must be a duck"?

// DESIGN PRINCIPLE
//		DESIGN TOWARDS ABSTRACT TYPE RATHER THAN CONCRETE TYPE
//	Corollary
//		DESIGN TOWARDS INTERFACE RATHER THAN CONCRETE CLASS

// Contract
// interface Creates Abstract Type [ Mathematical ]
//		Associates Members Of Different Types

// interface Creates Abstract Type [ Mathematical ]
// 	= { Operations, Range }
//			Operations = { area(), perimeter() }
//			Range = Phi Set
type Geometry interface {
	area() float64
	perimeter() float64
	// origin() (float64, float64 )
}

// struct Creates Associative Type
//		Associates Members Of Different Types

// In Java
//		Explicitly Make Rectangle Geometry
// class Rectangle implements Geometry {

// }

type Rectangle struct {
	width, height float64
}

type Circle struct {
	radius float64
}

// Rectangle Type Methods
func ( r Rectangle ) area() float64 {
	return r.width * r.height
}

func ( r Rectangle ) perimeter() float64 {
	return 2 *( r.width + r.height )
}

func ( r Rectangle ) origin() (float64, float64) {
	return  0.0, 0.0 
}

// Circle Type Methods
func ( c Circle ) area() float64 {
	return math.Pi * c.radius * c.radius
}

func ( c Circle ) perimeter() float64 {
	return 2 * math.Pi * c.radius
}

// Polymorphic Function
func measureGeometry( g Geometry ) {
	fmt.Println( g )
	fmt.Println( g.area() )
	fmt.Println( g.perimeter() )
}

func playWithGeometry() {
	r := Rectangle{ width : 10, height: 20 }
	c := Circle{ radius : 10 }

	fmt.Println("Rectangle Area: ", r.area() )
	fmt.Println("Rectangle perimeter: ", r.perimeter() )

	fmt.Println("Circle Area: ", c.area() )
	fmt.Println("Circle perimeter: ", c.perimeter() )

	measureGeometry( r )
	// Circle does not implement Geometry (missing origin method)
	measureGeometry( c )
}

//__________________________________________________________________

/*
package fmt

func Fprintf(w io.Writer, format string, args ...interface{}) (int, error)

func Printf(format string, args ...interface{}) (int, error) {
	 return Fprintf(os.Stdout, format, args...)
}

func Sprintf(format string, args ...interface{}) string {
	var buf bytes.Buffer
	Fprintf(&buf, format, args...)
	return buf.String()
}  

package io

type Writer interface {
	// Write writes len(p) bytes from p to the underlying data stream.
	// It returns the number of bytes written from p (0 <= n <= len(p))
	// and any error encountered that caused the write to stop early.
	// Write must return a non-nil error if it returns n < len(p).
	// Write must not modify the slice data, even temporarily.
	//
	// Implementations must not retain p.
	Write(p []byte) (n int, err error)
}

*/

//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
//__________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithGeometry")
	playWithGeometry()

	fmt.Println("\nFunction : playWithGeometry")
	playWithGeometry()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}

