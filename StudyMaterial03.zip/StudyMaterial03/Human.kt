
// class Spiderman {
// 	fun fly() 		{ println("Fly Like Spiderman!") }
// 	fun saveWorld() { println("SaveWorld Like Spiderman!") }
// }

// DESIGN PRINCIPLE
//		DESIGN TOWARDS ABSTRACT TYPE RATHER THAN CONCRETE TYPE
//	Corollary
//		DESIGN TOWARDS INTERFACE RATHER THAN CONCRETE CLASS

// What To Do?
interface Superpower {
	fun fly()
	fun saveWorld()
}

// When, Where, Which Way, How, WHy To Do?
open  class SpidermanOld {
	open fun fly() 		{ println("Fly Like Spiderman!") }
	open fun saveWorld() { println("SaveWorld Like Spiderman!") }
}

class Spiderman : Superpower {
	override fun fly() 		{ println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }
}

class Superman : Superpower {
	override fun fly() 		{ println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }
}

class Wonderwoman : Superpower {
	override fun fly() 		{ println("Fly Like Wonderwoman!") }
	override fun saveWorld() { println("SaveWorld Like Wonderwoman!") }
}

class HanjumanJi : Superpower {
	override fun fly() 			{ println("Fly Like HanjumanJi!") }
	override fun saveWorld() 	{ println("SaveWorld Like HanjumanJi!") }
}

//____________________________________________________________

// Using Mechanism Inheritance
class Human : SpidermanOld()  {
// class Human : Superman()  {
// class Human : Wonderwoman()  {
	override fun fly() 		{ super.fly() }	//{ println("Fly Like Human!") }
	override fun saveWorld(){ super.saveWorld() } 	//{ println("SaveWorld Like Human!") }
}

//____________________________________________________________

// Using Mechanism Composition
class HumanAgain  {
	var power : Spiderman = Spiderman()
	// var power : Superman = Superman()
	// var power : Wonderwoman = Wonderwoman()

	fun fly() 		{ power.fly() }	//{ println("Fly Like Human!") }
	fun saveWorld() { power.saveWorld() } 	//{ println("SaveWorld Like Human!") }
}

//____________________________________________________________

// Polymorphic HumanBetter
// Using Mechanism Composition
class HumanBetter  {
	// var power : Spiderman = Spiderman()
	// var power : Superman = Superman()
	// var power : Wonderman = Wonderman()
	var power : Superpower? = null
	fun fly() 		{ power?.fly() }	//{ println("Fly Like Human!") }
	fun saveWorld() { power?.saveWorld() } 	//{ println("SaveWorld Like Human!") }
}

//____________________________________________________________

fun main() {
	val human = Human()
	human.fly()
	human.saveWorld()

	val humanAgain = HumanAgain()
	humanAgain.fly()
	humanAgain.saveWorld()

	val humanBetter = HumanBetter()
	humanBetter.power = Spiderman()
	humanBetter.fly()
	humanBetter.saveWorld()

	humanBetter.power = Superman()
	humanBetter.fly()
	humanBetter.saveWorld()

	humanBetter.power = Wonderwoman()
	humanBetter.fly()
	humanBetter.saveWorld()

	humanBetter.power = HanjumanJi()
	humanBetter.fly()
	humanBetter.saveWorld()
}

